CROSSWORD QUEST PWA FILES

Upload these files into the ROOT of your existing GitHub repository (same folder as index.html):
- index.html (replace your existing index.html with this PWA-enabled version)
- manifest.json
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png

If uploading through GitHub mobile: Code > Add file > Upload files. Upload manifest.json and service-worker.js at the repository root. For icons, create an icons folder and upload both PNG files inside it. Replace the existing index.html with the one in this package. Commit changes.

Then wait a few minutes, open the live HTTPS site in Chrome, tap ⋮ > Install app (or Add to Home screen). Service worker caching means offline support begins after the site is loaded online at least once.
